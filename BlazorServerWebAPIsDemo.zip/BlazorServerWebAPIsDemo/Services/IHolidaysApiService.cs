﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorServerWebAPIsDemo.Models;

namespace BlazorServerWebAPIsDemo.Services
{
    public interface IHolidaysApiService
    {
        Task<List<HolidayResponseModel>> GetHolidays(HolidayRequestModel holidaysRequest);
    }
}
