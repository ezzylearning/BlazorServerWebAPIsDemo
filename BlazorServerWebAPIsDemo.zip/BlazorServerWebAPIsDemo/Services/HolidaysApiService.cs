﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using BlazorServerWebAPIsDemo.Models;

namespace BlazorServerWebAPIsDemo.Services
{
    public class HolidaysApiService : IHolidaysApiService
    {
        private readonly HttpClient _httpClient;

        public HolidaysApiService(HttpClient client)
        {
            _httpClient = client;
        }

        public async Task<List<HolidayResponseModel>> GetHolidays(HolidayRequestModel holidaysRequest)
        {
            var result = new List<HolidayResponseModel>();

            var url = string.Format("api/v2/PublicHolidays/{0}/{1}",
                holidaysRequest.Year, holidaysRequest.CountryCode);

            var response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var stringResponse = await response.Content.ReadAsStringAsync();

                result = JsonSerializer.Deserialize<List<HolidayResponseModel>>(stringResponse,
                    new JsonSerializerOptions() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            }
            else
            {
                result = Array.Empty<HolidayResponseModel>().ToList();
            }

            return result;
        }
    }
}
