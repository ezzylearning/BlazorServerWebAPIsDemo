﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorServerWebAPIsDemo.Models;
using BlazorServerWebAPIsDemo.Services;
using Microsoft.AspNetCore.Components;

namespace BlazorServerWebAPIsDemo.Pages
{
    public partial class HolidaysExplorer
    {
        private HolidayRequestModel HolidaysModel = new HolidayRequestModel();
        private List<HolidayResponseModel> Holidays = new List<HolidayResponseModel>();

        [Inject]
        protected IHolidaysApiService HolidaysApiService { get; set; }

        private async Task HandleValidSubmit()
        {
            Holidays = await HolidaysApiService.GetHolidays(HolidaysModel);
        }
    }
}
