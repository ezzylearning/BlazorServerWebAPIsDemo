
using System;
using BlazorServerWebAPIsDemo.Services;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BlazorServerWebAPIsDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddServerSideBlazor();

            services.AddSingleton<IHolidaysApiService, HolidaysApiService>();

            //services.AddHttpClient();

            //services.AddHttpClient("HolidaysApi", c =>
            //{
            //    c.BaseAddress = new Uri("https://date.nager.at/");
            //    c.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
            //});

            //services.AddHttpClient<HolidaysApiService>();

            services.AddHttpClient<IHolidaysApiService, HolidaysApiService>(c =>
            {
                c.BaseAddress = new Uri("https://date.nager.at/");
                c.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
